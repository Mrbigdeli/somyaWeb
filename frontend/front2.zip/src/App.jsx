// import { getRequest } from "./utils/API";
import Home from "./pages/Home/Home";
function App() {
  return (
    <div className="App">
      <Home />
    </div>
  );
}

export default App;
