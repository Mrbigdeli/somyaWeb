
const Footer = () => {
  return (
    <footer className="footer">تمامی حقوق برای سومیا وب محفوظ است .</footer>
  );
};

export default Footer;
