const Home = () => {
  return (
    <div id="home-pge-parent">
      <p>hello</p>
    </div>
  );
};
export default Home;
